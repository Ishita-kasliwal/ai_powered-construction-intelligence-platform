import React, { useState } from 'react';
import { Activity, Building2, CalendarDays, CloudSun, HardHat, Image, MessageSquareText, ShieldCheck, Sparkles, TrendingUp, Upload, Menu, X, ArrowUpRight, CheckCircle2, AlertTriangle } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const modules = [
  {id:'overview', label:'Overview', icon:Activity},
  {id:'safety', label:'Site safety monitor', icon:ShieldCheck},
  {id:'cracks', label:'Crack analysis', icon:Image},
  {id:'valuation', label:'Property valuation', icon:TrendingUp},
  {id:'planning', label:'Project planner', icon:CalendarDays},
  {id:'weather', label:'Weather advisory', icon:CloudSun},
  {id:'assistant', label:'Knowledge assistant', icon:MessageSquareText},
];
function App(){
  const [active,setActive] = useState('overview');
  const [mobileNav,setMobileNav] = useState(false);
  const [busy,setBusy] = useState(false);
  const [result,setResult] = useState(null);
  const [error,setError] = useState('');
  const [file,setFile] = useState(null);
  const [form,setForm] = useState({site_context:'Residential construction site',notes:'',area_sqft:'1200',rate_per_sqft:'3500',location:'Indore, Madhya Pradesh',property_type:'Residential',age_years:'5',condition:'Good',project_type:'Residential building',floors:'3',target_days:'180',budget:'8500000',temperature_c:'32',rainfall_mm:'0',wind_kmh:'12',humidity_pct:'55',task:'Concrete work',question:'What should be checked before concrete pouring?',context:'Small residential construction project'});
  const update=(k,v)=>setForm(p=>({...p,[k]:v}));
  const reset=()=>{setResult(null);setError('');setFile(null)};
  async function submit(e){
    e?.preventDefault(); setBusy(true); setError(''); setResult(null);
    try{
      let response;
      if(active==='safety'||active==='cracks'){
        if(!file) throw new Error('Please choose a site image first.');
        const fd=new FormData(); fd.append('image',file); fd.append('notes',form.notes);
        if(active==='safety') fd.append('site_context',form.site_context);
        response=await fetch(`${API}/api/${active==='safety'?'safety':'cracks'}/analyze`,{method:'POST',body:fd});
      } else {
        const endpoints={valuation:'/api/valuation/estimate',planning:'/api/planning/generate',weather:'/api/weather/advisory',assistant:'/api/assistant/ask'};
        const payloads={
          valuation:{area_sqft:+form.area_sqft,rate_per_sqft:+form.rate_per_sqft,location:form.location,property_type:form.property_type,age_years:+form.age_years,condition:form.condition},
          planning:{project_type:form.project_type,floors:+form.floors,area_sqft:+form.area_sqft,target_days:+form.target_days,budget:+form.budget,notes:form.notes},
          weather:{temperature_c:+form.temperature_c,rainfall_mm:+form.rainfall_mm,wind_kmh:+form.wind_kmh,humidity_pct:+form.humidity_pct,task:form.task},
          assistant:{question:form.question,context:form.context}
        };
        response=await fetch(`${API}${endpoints[active]}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payloads[active])});
      }
      const data=await response.json();
      if(!response.ok) throw new Error(data.detail||'Request failed. Check that the backend is running.');
      setResult(data);
    }catch(err){setError(err.message||'Unable to connect to backend.');}
    finally{setBusy(false)}
  }
  const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n||0);
  const current=modules.find(m=>m.id===active);
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'open':''}`}>
      <div className="brand"><div className="brand-mark"><Building2 size={22}/></div><div><strong>BuildSense</strong><span>CONSTRUCTION INTELLIGENCE</span></div><button className="close-nav" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{modules.map(item=>{const Icon=item.icon;return <button key={item.id} className={`nav-item ${active===item.id?'selected':''}`} onClick={()=>{setActive(item.id);reset();setMobileNav(false)}}><Icon size={18}/><span>{item.label}</span>{item.id==='safety'&&<span className="nav-dot"/>}</button>})}</nav>
      <div className="sidebar-bottom"><div className="status-icon"><Sparkles size={18}/></div><div><b>AI workspace</b><p>Decision support for your site</p></div><span className="online-dot"/></div>
      <div className="profile"><div className="avatar">BS</div><div><b>Project workspace</b><span>Local demo environment</span></div><span className="more">•••</span></div>
    </aside>
    {mobileNav&&<div className="scrim" onClick={()=>setMobileNav(false)}/>}
    <main className="main">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobileNav(true)}><Menu size={20}/></button><div className="crumb">Workspace <span>/</span> <b>{current.label}</b></div><div className="top-actions"><span className="system-status"><i/> System ready</span><div className="top-avatar">BS</div></div></header>
      <div className="page">
        <section className="welcome"><div><div className="eyebrow"><span className="eyebrow-line"/> CONSTRUCTION OPERATIONS PLATFORM</div><h1>{active==='overview'?'Build with better intelligence.':current.label}</h1><p>{active==='overview'?'Bring site observations, project planning and practical guidance into one clear workspace.':'Use AI-assisted tools to support decisions, organize observations and plan your next steps.'}</p></div><div className="welcome-icon"><HardHat size={32}/><span/></div></section>
        {active==='overview'?<Overview setActive={id=>{setActive(id);reset()}}/>:<>
          <section className="tool-card"><div className="tool-heading"><div className="tool-symbol"><current.icon size={21}/></div><div><h2>{current.label}</h2><p>{descriptions[active]}</p></div><span className="beta-pill">AI ASSISTED</span></div>
          <form onSubmit={submit}>
            {(active==='safety'||active==='cracks')&&<><div className="field-grid">{active==='safety'&&<Field label="Site context"><input value={form.site_context} onChange={e=>update('site_context',e.target.value)} /></Field>}<Field label="Observation notes" wide><textarea rows="2" value={form.notes} onChange={e=>update('notes',e.target.value)} placeholder="Add location, observed issue or site conditions…"/></Field></div><label className="upload-box"><input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)}/><div className="upload-icon"><Upload size={22}/></div><b>{file?file.name:'Upload a construction image'}</b><span>{file?`${(file.size/1024/1024).toFixed(2)} MB · Click to change`:'PNG, JPG or WEBP · Up to 8 MB'}</span></label></>}
            {active==='valuation'&&<div className="field-grid"><Field label="Built-up area (sq ft)"><input type="number" min="1" value={form.area_sqft} onChange={e=>update('area_sqft',e.target.value)} required/></Field><Field label="Rate per sq ft (₹)"><input type="number" min="1" value={form.rate_per_sqft} onChange={e=>update('rate_per_sqft',e.target.value)} required/></Field><Field label="Location"><input value={form.location} onChange={e=>update('location',e.target.value)} required/></Field><Field label="Property type"><select value={form.property_type} onChange={e=>update('property_type',e.target.value)}><option>Residential</option><option>Commercial</option><option>Industrial</option><option>Land</option></select></Field><Field label="Property age (years)"><input type="number" min="0" value={form.age_years} onChange={e=>update('age_years',e.target.value)}/></Field><Field label="Condition"><select value={form.condition} onChange={e=>update('condition',e.target.value)}>{['Excellent','Good','Fair','Poor'].map(x=><option key={x}>{x}</option>)}</select></Field></div>}
            {active==='planning'&&<div className="field-grid"><Field label="Project type"><select value={form.project_type} onChange={e=>update('project_type',e.target.value)}><option>Residential building</option><option>Commercial building</option><option>Road construction</option><option>Renovation</option><option>Warehouse</option></select></Field><Field label="Number of floors"><input type="number" min="1" value={form.floors} onChange={e=>update('floors',e.target.value)}/></Field><Field label="Project area (sq ft)"><input type="number" min="1" value={form.area_sqft} onChange={e=>update('area_sqft',e.target.value)}/></Field><Field label="Target duration (days)"><input type="number" min="1" value={form.target_days} onChange={e=>update('target_days',e.target.value)}/></Field><Field label="Estimated budget (₹)"><input type="number" min="1" value={form.budget} onChange={e=>update('budget',e.target.value)}/></Field><Field label="Additional requirements" wide><textarea rows="2" value={form.notes} onChange={e=>update('notes',e.target.value)} placeholder="Site constraints, materials, milestones…"/></Field></div>}
            {active==='weather'&&<div className="field-grid"><Field label="Temperature (°C)"><input type="number" value={form.temperature_c} onChange={e=>update('temperature_c',e.target.value)}/></Field><Field label="Rainfall (mm)"><input type="number" min="0" value={form.rainfall_mm} onChange={e=>update('rainfall_mm',e.target.value)}/></Field><Field label="Wind speed (km/h)"><input type="number" min="0" value={form.wind_kmh} onChange={e=>update('wind_kmh',e.target.value)}/></Field><Field label="Humidity (%)"><input type="number" min="0" max="100" value={form.humidity_pct} onChange={e=>update('humidity_pct',e.target.value)}/></Field><Field label="Planned activity" wide><input value={form.task} onChange={e=>update('task',e.target.value)}/></Field></div>}
            {active==='assistant'&&<div className="field-grid"><Field label="Your question" wide><textarea rows="3" value={form.question} onChange={e=>update('question',e.target.value)} required/></Field><Field label="Project context (optional)" wide><textarea rows="2" value={form.context} onChange={e=>update('context',e.target.value)}/></Field></div>}
            <div className="form-footer"><span><ShieldCheck size={15}/> Results are advisory. Verify critical decisions.</span><button className="primary-btn" disabled={busy}>{busy?'Working…':active==='safety'||active==='cracks'?'Analyze image':'Generate insights'} <ArrowUpRight size={16}/></button></div>
          </form></section>
          {error&&<div className="error-banner"><AlertTriangle size={18}/><span>{error}</span></div>}
          {result&&<ResultPanel result={result} money={money}/>}
        </>}
        <footer><span>BuildSense <b>·</b> Construction Intelligence Platform</span><span><i/> API-ready workspace <b>·</b> Demo build</span></footer>
      </div>
    </main>
  </div>
}
const descriptions={safety:'Review site photos and organize safety observations.',cracks:'Record visible cracks and receive cautious inspection guidance.',valuation:'Estimate an indicative property value from basic inputs.',planning:'Create a provisional construction phase plan and budget split.',weather:'Turn entered weather conditions into site-work precautions.',assistant:'Ask practical construction questions with project context.'};
function Field({label,children,wide}){return <label className={`field ${wide?'wide':''}`}><span>{label}</span>{children}</label>}
function Overview({setActive}){
  const cards=[{id:'safety',title:'Site safety monitoring',desc:'Review visible site conditions and safety checklists.',icon:ShieldCheck,tone:'blue',tag:'IMAGE ANALYSIS'},{id:'cracks',title:'Crack analysis',desc:'Document cracks and identify when expert review is needed.',icon:Image,tone:'purple',tag:'MAINTENANCE'},{id:'planning',title:'Project planning',desc:'Outline project phases, timing and indicative budgets.',icon:CalendarDays,tone:'orange',tag:'SCHEDULING'},{id:'valuation',title:'Real estate valuation',desc:'Build a quick estimate from area, rate and condition.',icon:TrendingUp,tone:'green',tag:'ESTIMATION'}];
  return <><section className="stats-grid"><div className="stat-card"><div className="stat-top"><span>INTELLIGENCE MODULES</span><div className="stat-icon blue"><Sparkles size={17}/></div></div><strong>06</strong><p>Tools in one workspace</p><div className="stat-foot"><span className="tiny-check"><CheckCircle2 size={13}/></span> API-connected modules</div></div><div className="stat-card"><div className="stat-top"><span>PROJECT STATUS</span><div className="stat-icon green"><Activity size={17}/></div></div><strong>Ready</strong><p>Local demo environment</p><div className="stat-foot"><span className="green-text">●</span> Backend connection required</div></div><div className="stat-card"><div className="stat-top"><span>AI MODE</span><div className="stat-icon purple"><Sparkles size={17}/></div></div><strong className="mode-value">AI-ready</strong><p>Optional multimodal provider</p><div className="stat-foot"><span className="neutral-dot"/> Demo fallback available</div></div></section>
  <div className="section-title"><div><h2>Intelligence tools</h2><p>Choose a module to start a focused workflow.</p></div><span className="count-pill">06 MODULES</span></div>
  <section className="module-grid">{cards.map(c=>{const Icon=c.icon;return <button className="module-card" key={c.id} onClick={()=>setActive(c.id)}><div className={`module-icon ${c.tone}`}><Icon size={21}/></div><span className="module-tag">{c.tag}</span><h3>{c.title}</h3><p>{c.desc}</p><span className="module-link">Open tool <ArrowUpRight size={15}/></span></button>})}</section>
  <section className="assistant-banner"><div className="banner-icon"><MessageSquareText size={23}/></div><div><span>NEED A QUICK ANSWER?</span><h3>Ask the construction knowledge assistant</h3><p>Get general guidance, checklists and practical next steps.</p></div><button onClick={()=>setActive('assistant')}>Ask a question <ArrowUpRight size={16}/></button></section></>
}
function ResultPanel({result,money}){
 const [showRaw,setShowRaw]=useState(false);
 return <section className="result-card"><div className="result-head"><div><span className="result-kicker"><Sparkles size={14}/> GENERATED INSIGHTS</span><h2>{result.summary||'Analysis result'}</h2></div><span className={`mode-pill ${result.mode==='ai'?'live':''}`}>{result.mode==='ai'?'AI response':result.mode==='demo'?'Demo response':'Result'}</span></div>
 {result.estimated_value!==undefined&&<div className="estimate-value"><span>Indicative property value</span><strong>{money(result.estimated_value)}</strong></div>}
 {result.conditions&&<div className="conditions-row">{Object.entries(result.conditions).map(([k,v])=><span key={k}><b>{k.replaceAll('_',' ')}</b>{String(v)}</span>)}</div>}
 {result.findings?.length>0&&<div className="result-section"><h3>Observations</h3><ul>{result.findings.map((x,i)=><li key={i}>{typeof x==='string'?x:JSON.stringify(x)}</li>)}</ul></div>}
 {result.alerts?.length>0&&<div className="result-section"><h3>Alerts</h3><ul>{result.alerts.map((x,i)=><li key={i}>{x}</li>)}</ul></div>}
 {result.schedule&&<div className="result-section"><h3>Provisional project schedule</h3><div className="schedule-list">{result.schedule.map((p,i)=><div className="schedule-row" key={i}><div className="phase-num">{String(i+1).padStart(2,'0')}</div><div className="phase-main"><b>{p.phase}</b><span>Day {p.start_day} · {p.duration_days} days</span><div className="progress-track"><i style={{width:`${Math.max(8,p.duration_days/Math.max(...result.schedule.map(x=>x.duration_days))*100)}%`}}/></div></div><b className="phase-budget">{money(p.indicative_budget_inr)}</b></div>)}</div><p className="small-muted">Planned duration: {result.total_planned_days} days (phase estimates may need adjustment).</p></div>}
 {result.recommendations?.length>0&&<div className="result-section"><h3>Recommended next steps</h3><ul>{result.recommendations.map((x,i)=><li key={i}>{typeof x==='string'?x:JSON.stringify(x)}</li>)}</ul></div>}
 {result.disclaimer&&<div className="disclaimer"><AlertTriangle size={16}/><span>{result.disclaimer}</span></div>}
 <button className="raw-toggle" onClick={()=>setShowRaw(!showRaw)}>{showRaw?'Hide':'View'} JSON response</button>{showRaw&&<pre className="raw-json">{JSON.stringify(result,null,2)}</pre>}
 </section>
}
