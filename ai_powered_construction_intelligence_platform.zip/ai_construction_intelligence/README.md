# AI-Powered Multimodal Construction Intelligence Platform

A full-stack starter MVP with a React + Vite frontend and FastAPI backend. It provides a dashboard for:
- Site safety monitoring (image upload + AI-ready analysis endpoint)
- Crack detection and analysis (image upload + AI-ready analysis endpoint)
- Real estate valuation estimate
- Construction project planning
- Daily site assistance
- Weather-aware advisory (manual weather inputs; no external weather key required)
- Construction knowledge assistant

## Tech stack
- Frontend: React, Vite, plain CSS
- Backend: Python, FastAPI, Pydantic, Pillow
- Optional AI: OpenAI-compatible multimodal API via environment variables
- Fallback: deterministic demo responses so the project runs without an API key

## Run locally

### 1. Backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```
Backend: http://127.0.0.1:8000  
API docs: http://127.0.0.1:8000/docs

### 2. Frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL Vite prints (usually http://localhost:5173).

## Optional real AI integration
Copy `backend/.env.example` to `backend/.env` and configure:
- `AI_API_KEY` — API key for an OpenAI-compatible endpoint
- `AI_BASE_URL` — optional base URL (defaults to OpenAI API)
- `AI_MODEL` — model name that supports image input if you want image analysis

Without these values, demo-mode responses are returned. Keep API keys in the backend `.env`; never place them in frontend code.

## Important limitations
- Safety and crack outputs are decision-support suggestions, not certified inspections or engineering diagnoses.
- The valuation and planning modules are educational estimates. Verify assumptions with qualified professionals and local data.
- The demo weather advisor uses weather details entered by the user; it does not fetch live weather.
- This is a project MVP, not a production-ready system. Add authentication, database persistence, audit logging, rate limiting, secure deployment, and tests before production use.
