import base64
import io
import json
import os
from typing import Optional
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from PIL import Image

load_dotenv()

app = FastAPI(
    title="Construction Intelligence API",
    description="Decision-support APIs for construction planning, safety, images and knowledge assistance.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SiteSafetyRequest(BaseModel):
    site_context: str = Field(default="General construction site", max_length=2000)
    notes: str = Field(default="", max_length=5000)

class ValuationRequest(BaseModel):
    area_sqft: float = Field(gt=0, le=10_000_000)
    rate_per_sqft: float = Field(gt=0, le=10_000_000)
    location: str = Field(min_length=2, max_length=200)
    property_type: str = "Residential"
    age_years: float = Field(default=0, ge=0, le=200)
    condition: str = "Good"

class PlanRequest(BaseModel):
    project_type: str = "Residential building"
    floors: int = Field(default=2, ge=1, le=100)
    area_sqft: float = Field(default=2000, gt=0, le=10_000_000)
    target_days: int = Field(default=120, ge=1, le=5000)
    budget: float = Field(default=5000000, gt=0)
    notes: str = Field(default="", max_length=5000)

class AssistantRequest(BaseModel):
    question: str = Field(min_length=2, max_length=5000)
    context: str = Field(default="", max_length=5000)

class WeatherRequest(BaseModel):
    temperature_c: float = Field(ge=-30, le=65)
    rainfall_mm: float = Field(default=0, ge=0, le=1000)
    wind_kmh: float = Field(default=0, ge=0, le=400)
    humidity_pct: float = Field(default=50, ge=0, le=100)
    task: str = "General site work"

def json_response(module: str, summary: str, findings: list, recommendations: list, disclaimer: str = ""):
    return {
        "module": module,
        "summary": summary,
        "findings": findings,
        "recommendations": recommendations,
        "disclaimer": disclaimer,
        "mode": "demo" if not os.getenv("AI_API_KEY") else "ai-ready"
    }

async def multimodal_or_demo(system_prompt: str, user_text: str, image_data_url: Optional[str] = None):
    """Use an OpenAI-compatible multimodal endpoint when configured; safely fall back to a demo response."""
    api_key = os.getenv("AI_API_KEY")
    if not api_key:
        return None
    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=api_key, base_url=os.getenv("AI_BASE_URL") or None)
        content = [{"type": "text", "text": user_text}]
        if image_data_url:
            content.append({"type": "image_url", "image_url": {"url": image_data_url}})
        result = await client.chat.completions.create(
            model=os.getenv("AI_MODEL", "gpt-4o-mini"),
            temperature=0.2,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system_prompt + " Return valid JSON with keys: summary, findings (array), recommendations (array), disclaimer."},
                {"role": "user", "content": content},
            ],
        )
        parsed = json.loads(result.choices[0].message.content or "{}")
        return parsed
    except Exception as exc:
        # Do not expose credentials or upstream internals to clients.
        return {"summary": "AI provider could not be reached; showing a safe fallback result.", "findings": [str(type(exc).__name__)], "recommendations": ["Check backend AI_API_KEY, AI_BASE_URL and AI_MODEL, then retry."], "disclaimer": "Demo fallback; this is not a certified inspection."}

async def read_image(file: UploadFile):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Please upload an image file.")
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded image is empty.")
    if len(data) > 8 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image must be 8 MB or smaller.")
    try:
        image = Image.open(io.BytesIO(data))
        image.verify()
    except Exception:
        raise HTTPException(status_code=400, detail="The uploaded file is not a valid image.")
    mime = file.content_type if file.content_type in ("image/jpeg", "image/png", "image/webp", "image/gif") else "image/jpeg"
    return data, f"data:{mime};base64,{base64.b64encode(data).decode('ascii')}"

@app.get("/")
def root():
    return {"name": "Construction Intelligence API", "status": "ok", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok", "ai_configured": bool(os.getenv("AI_API_KEY"))}

@app.post("/api/safety/analyze")
async def safety_analyze(
    site_context: str = Form("General construction site"),
    notes: str = Form(""),
    image: UploadFile = File(...)
):
    _, image_url = await read_image(image)
    result = await multimodal_or_demo(
        "You are a cautious construction site safety assistant. Identify only visible hazards and uncertainty. Never claim a site is safe based on one image.",
        f"Review this construction-site image. Context: {site_context}. Additional notes: {notes}. Return practical, prioritized safety observations.",
        image_url
    )
    if result:
        return {"module": "site_safety", **result, "mode": "ai" if os.getenv("AI_API_KEY") else "demo"}
    return json_response("site_safety", "Image received. Demo mode cannot reliably inspect visual hazards without an AI provider.", [
        "No automated visual detection is active in demo mode.",
        f"Site context supplied: {site_context}",
        "A single image may miss hazards outside the frame."
    ], [
        "Check PPE (helmet, high-visibility vest, boots, eye protection) against site rules.",
        "Inspect edges, openings, scaffolding, electrical leads, lifting zones and housekeeping.",
        "Pause unsafe work and ask the site safety officer to verify hazards."
    ], "Decision support only. Do not use this response as a certified safety inspection.")

@app.post("/api/cracks/analyze")
async def crack_analyze(
    notes: str = Form(""),
    image: UploadFile = File(...)
):
    _, image_url = await read_image(image)
    result = await multimodal_or_demo(
        "You are a cautious building-maintenance assistant. Describe visible crack characteristics; do not diagnose structural safety from an image alone.",
        f"Review this wall/concrete image for visible cracks. Notes: {notes}. Return observations, possible non-diagnostic explanations, and safe next steps.",
        image_url
    )
    if result:
        return {"module": "crack_analysis", **result, "mode": "ai" if os.getenv("AI_API_KEY") else "demo"}
    return json_response("crack_analysis", "Image uploaded. Demo mode does not perform actual computer-vision crack detection.", [
        "Crack width, depth, movement and cause cannot be established from this demo endpoint.",
        f"Notes: {notes or 'No extra notes supplied.'}"
    ], [
        "Photograph with a scale and record date and location.",
        "Track whether the crack changes over time; do not cover it before assessment.",
        "For wide, growing, diagonal structural cracks, displacement, water ingress or sagging, restrict access as appropriate and contact a qualified structural engineer."
    ], "Not a structural diagnosis or substitute for an on-site inspection.")

@app.post("/api/valuation/estimate")
def valuation(req: ValuationRequest):
    condition_factor = {"Excellent": 1.05, "Good": 1.0, "Fair": 0.88, "Poor": 0.72}.get(req.condition, 1.0)
    age_factor = max(0.55, 1 - min(req.age_years, 100) * 0.004)
    base = req.area_sqft * req.rate_per_sqft
    estimate = base * condition_factor * age_factor
    return {
        "module": "real_estate_valuation",
        "summary": "Indicative estimate calculated from the inputs provided.",
        "estimated_value": round(estimate, 2),
        "currency": "INR",
        "calculation": {
            "area_sqft": req.area_sqft, "rate_per_sqft": req.rate_per_sqft,
            "location": req.location, "property_type": req.property_type,
            "age_years": req.age_years, "condition": req.condition,
            "condition_factor": condition_factor, "age_factor": round(age_factor, 3)
        },
        "recommendations": ["Compare recent registered transactions and local listings.", "Adjust for land value, amenities, floor, legal status, and current market conditions."],
        "disclaimer": "Illustrative estimate only; not a formal valuation or financial advice."
    }

@app.post("/api/planning/generate")
async def planning(req: PlanRequest):
    result = await multimodal_or_demo(
        "You are a construction project planning assistant. Use practical phases and clearly label estimates as provisional.",
        f"Create a high-level construction plan. Project type={req.project_type}; floors={req.floors}; area_sqft={req.area_sqft}; target_days={req.target_days}; budget INR={req.budget}; notes={req.notes}"
    )
    if result:
        return {"module": "project_planning", **result, "mode": "ai"}
    phases = [
        ("Requirements, survey and approvals", 0.10),
        ("Design and procurement", 0.15),
        ("Site preparation and foundation", 0.20),
        ("Structure and masonry", 0.25),
        ("MEP and finishing", 0.22),
        ("Inspection and handover", 0.08),
    ]
    schedule = []
    cursor = 1
    for name, fraction in phases:
        days = max(1, round(req.target_days * fraction))
        schedule.append({"phase": name, "start_day": cursor, "duration_days": days, "indicative_budget_inr": round(req.budget * fraction, 2)})
        cursor += days
    return {"module": "project_planning", "summary": "Provisional high-level plan generated using standard phase proportions.", "schedule": schedule, "total_planned_days": cursor - 1, "recommendations": ["Confirm local approvals, soil report and drawings before committing the baseline.", "Add dependencies, labour availability, procurement lead times and contingency.", "Review progress weekly and update the critical path."], "disclaimer": "Illustrative planning aid, not a contractor quotation or engineering schedule.", "mode": "demo"}

@app.post("/api/assistant/ask")
async def assistant(req: AssistantRequest):
    result = await multimodal_or_demo(
        "You are a practical construction knowledge assistant. Give concise, safety-aware guidance, state assumptions and recommend qualified review for regulated engineering decisions.",
        f"Question: {req.question}\nContext: {req.context}"
    )
    if result:
        return {"module": "construction_assistant", **result, "mode": "ai"}
    return json_response("construction_assistant", "Demo answer: use a documented, standards-led process and verify project-specific requirements.", [
        f"Question received: {req.question}",
        f"Context: {req.context or 'No project context supplied.'}"
    ], [
        "Check the latest applicable local building codes and project specifications.",
        "Document assumptions, approvals, inspection results and changes.",
        "For structural, electrical, fire-safety or legal decisions, consult the appropriately qualified professional."
    ], "Demo mode provides general guidance only.")

@app.post("/api/weather/advisory")
def weather(req: WeatherRequest):
    alerts, recs = [], []
    if req.rainfall_mm >= 10:
        alerts.append("Rain may affect excavation, concrete placement, access and electrical safety.")
        recs.extend(["Protect excavations and materials from runoff.", "Follow the approved concrete and waterproofing procedure; do not place concrete in unsuitable conditions."])
    if req.temperature_c >= 38:
        alerts.append("High-temperature conditions may increase heat stress and affect material curing.")
        recs.extend(["Provide water, shade, rest breaks and heat-stress monitoring.", "Follow approved hot-weather concreting procedures where relevant."])
    if req.temperature_c <= 5:
        alerts.append("Cold conditions may affect worker safety and concrete curing.")
        recs.append("Check project-specific cold-weather procedures before concrete work.")
    if req.wind_kmh >= 35:
        alerts.append("Strong wind can affect lifting, work at height and loose materials.")
        recs.append("Check crane/equipment wind limits and suspend exposed work when required by site rules.")
    if req.humidity_pct >= 85:
        alerts.append("High humidity may slow drying of some finishes and coatings.")
        recs.append("Check manufacturer limits for coatings, adhesives and curing.")
    if not alerts:
        alerts.append("No threshold-based weather alert triggered by the values entered.")
        recs.append("Continue routine site monitoring and follow the official local forecast.")
    return {"module": "weather_advisory", "summary": f"Weather-aware advisory for: {req.task}", "conditions": req.model_dump(), "alerts": alerts, "recommendations": recs, "disclaimer": "Uses manually entered conditions, not live weather data. Follow official forecasts and site procedures."}
